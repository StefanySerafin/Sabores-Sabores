document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("hamburgerButton");
    const sidebar = document.getElementById("sidebarMenu");
    const closeBtn = document.getElementById("closeSidebar");
  
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.add("active");
    });
  
    closeBtn.addEventListener("click", () => {
      sidebar.classList.remove("active");
    });
  
    document.addEventListener("click", (e) => {
      if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
        sidebar.classList.remove("active");
      }
    });
  
    // ✅ Mobile Search Toggle
    const searchToggle = document.getElementById("mobileSearchToggle");
    const mobileSearchBar = document.getElementById("mobileSearchBar");
  
    if (searchToggle && mobileSearchBar) {
      searchToggle.addEventListener("click", () => {
        mobileSearchBar.classList.toggle("active");
      });
    }
  });
  
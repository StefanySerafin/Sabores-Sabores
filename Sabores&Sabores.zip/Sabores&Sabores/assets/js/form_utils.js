// Meses e anos de nascimento
document.addEventListener('DOMContentLoaded', function () {
  // Mês
  const meses = [
    "jan.", "fev.", "mar.", "abr.", "mai.", "jun.",
    "jul.", "ago.", "set.", "out.", "nov.", "dez."
  ];
  const mesSelect = document.querySelector('select[name="mes"]');
  if (mesSelect && mesSelect.length === 0) {
    meses.forEach((mes, i) => {
      const opt = new Option(mes, i + 1);
      mesSelect.appendChild(opt);
    });
  }

  // Anos
  const anoSelect = document.querySelector('select[name="ano"]');
  const anoAtual = new Date().getFullYear();
  for (let ano = anoAtual; ano >= 1900; ano--) {
    anoSelect.appendChild(new Option(ano, ano));
  }

  // Países (opcional — pode substituir por JSON externo se preferir)
  const paises = [
    "Brasil", "Portugal", "Angola", "Moçambique", "Cabo Verde",
    "Timor-Leste", "Guiné-Bissau", "São Tomé e Príncipe", "Outros"
  ];
  const paisSelect = document.querySelector('select[name="pais"]');
  paises.forEach(p => paisSelect.appendChild(new Option(p, p)));
});



document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (menuToggle && navLinks) {
        menuToggle.addEventListener("change", function () {
            if (menuToggle.checked) {
                navLinks.classList.add("show");
            } else {
                navLinks.classList.remove("show");
            }
        });
    }
});

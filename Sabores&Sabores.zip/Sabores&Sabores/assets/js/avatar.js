document.addEventListener("DOMContentLoaded", function () {
  const avatarInput = document.getElementById("avatarInput");
  const avatarPreview = document.getElementById("avatarPreview");
  const formAvatar = document.getElementById("formAvatar");
  const btnRemover = document.querySelector('button[name="remover_avatar"]');

  // Pré-visualização + upload via JavaScript
  if (avatarInput && avatarPreview) {
    avatarInput.addEventListener("change", function () {
      const file = this.files[0];
      if (!file) return;

      // Pré-visualização
      const reader = new FileReader();
      reader.onload = () => {
        avatarPreview.src = reader.result;
      };
      reader.readAsDataURL(file);

      // Upload via fetch
      const formData = new FormData();
      formData.append("avatar", file);

      fetch("editar_salvar.php", {
        method: "POST",
        body: formData,
      })
        .then(response => response.ok ? response.text() : Promise.reject("Erro no upload"))
        .then(() => {
          showSuccess("✅ Foto de perfil atualizada com sucesso!");
        })
        .catch(() => {
          showError("❌ Falha ao enviar imagem.");
        });
    });
  }

  // Remoção via JS
  if (btnRemover && formAvatar) {
    btnRemover.addEventListener("click", function (e) {
      e.preventDefault();
      if (confirm("Deseja realmente remover sua foto de perfil?")) {
        fetch("editar_salvar.php", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "remover_avatar=1"
        })
        .then(response => response.ok ? response.text() : Promise.reject("Erro"))
        .then(() => {
          avatarPreview.src = "https://ui-avatars.com/api/?name=Usuário&background=ccc&color=333&rounded=true";
          showSuccess("🗑️ Foto de perfil removida.");
        })
        .catch(() => {
          showError("❌ Erro ao remover a imagem.");
        });
      }
    });
  }

  // Funções de feedback
  function showSuccess(msg) {
    alert(msg); // Você pode trocar por toast ou HTML se quiser
  }

  function showError(msg) {
    alert(msg);
  }
});

// assets/js/alerts.js
function showAlert(message, type = "info") {
    const alertContainerId = "dynamic-alert-container";
    let container = document.getElementById(alertContainerId);

    if (!container) {
        container = document.createElement("div");
        container.id = alertContainerId;
        container.style.position = "fixed";
        container.style.top = "20px";
        container.style.right = "20px";
        container.style.zIndex = "1050";
        container.style.maxWidth = "400px";
        document.body.appendChild(container);
    }

    const alertDiv = document.createElement("div");
    alertDiv.className = `alert alert-${mapAlertType(type)} alert-dismissible fade show`;
    alertDiv.role = "alert";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
            <span aria-hidden="true">&times;</span>
        </button>
    `;

    container.appendChild(alertDiv);

    setTimeout(() => {
        $(alertDiv).alert('close');
    }, 5000);
}

function mapAlertType(type) {
    switch (type) {
        case "erro":
            return "danger";
        case "sucesso":
            return "success";
        case "info":
        default:
            return "info";
    }
}

  document.addEventListener("DOMContentLoaded", function () {
    const alert = document.querySelector('.alert-success');
    if (alert) {
      setTimeout(() => {
        alert.style.display = 'none';
      }, 3000);
    }
  });


document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("hamburgerButton");
    const sidebar = document.getElementById("sidebarMenu");
    const closeBtn = document.getElementById("closeSidebar");

    toggleBtn.addEventListener("click", () => {
        sidebar.classList.add("active");
    });

    closeBtn.addEventListener("click", () => {
        sidebar.classList.remove("active");
    });

    // Fechar ao clicar fora (opcional)
    document.addEventListener("click", (e) => {
        if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
            sidebar.classList.remove("active");
        }
    });
});

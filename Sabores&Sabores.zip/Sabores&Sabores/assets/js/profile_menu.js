document.addEventListener("DOMContentLoaded", function () {
    const profileBtn = document.getElementById("profileButton");
    const profileMenu = document.getElementById("profileMenu");
  
    if (profileBtn && profileMenu) {
      profileBtn.addEventListener("click", () => {
        profileMenu.classList.toggle("active");
      });
  
      document.addEventListener("click", function (event) {
        if (!profileMenu.contains(event.target) && !profileBtn.contains(event.target)) {
          profileMenu.classList.remove("active");
        }
      });
  
      const isLoggedIn = typeof userIsLoggedIn !== 'undefined' && userIsLoggedIn;
      const base = typeof basePath !== 'undefined' ? basePath : '';

      if (isLoggedIn) {
      profileMenu.innerHTML = `
        <a href="${base}pages/usuario/conta.php">Minha Conta</a>
        <a href="${base}pages/usuario/favoritos.php">Receitas Favoritas</a>
        <a href="${base}pages/usuario/editar.php">Editar Perfil</a>
        <hr>
        <a href="${base}logout.php">Sair</a>`;
  } else {
        profileMenu.innerHTML = `
          <a href="${base}pages/login.php">Entrar</a>
          <a href="${base}pages/cadastro.php">Cadastrar</a>
        `;
      }
    }
  });
  
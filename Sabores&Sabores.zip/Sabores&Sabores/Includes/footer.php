<script>
  const userIsLoggedIn = <?= $isLoggedIn ? 'true' : 'false' ?>;
  const basePath = "<?= $basePath ?>";
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Variáveis Globais JS -->
<script>
  const userIsLoggedIn = <?= $isLoggedIn ? 'true' : 'false' ?>;
  const basePath = "<?= $basePath ?>";
</script>

<!-- Scripts -->
  <script src="<?= $basePath ?>assets/js/alerts.js"></script>
  <script src="<?= $basePath ?>assets/js/profile_menu.js"></script>
  <script src="<?= $basePath ?>assets/js/sidebar_toggle.js"></script>
  <script src="<?= $basePath ?>assets/js/mobile_search_toggle.js"></script>
  <script src="<?= $basePath ?>assets/js/avatar.js"></script>
<script src="<?= $basePath ?>assets/js/form_utils.js"></script>
</body>
</html>

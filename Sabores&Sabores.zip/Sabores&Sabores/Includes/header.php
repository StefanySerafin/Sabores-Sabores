<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$isLoggedIn = isset($_SESSION['usuario_id']);
$basePath = (strpos($_SERVER['PHP_SELF'], '/pages/usuario/') !== false) ? '../../' :
            ((strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? '../' : '');

$fotoPerfilUrl = 'https://ui-avatars.com/api/?name=Usuário&background=ccc&color=333&rounded=true';

if ($isLoggedIn) {
    require_once $basePath . 'includes/db.php';

    $stmt = $pdo->prepare("SELECT nome_usuario, foto_perfil FROM usuarios WHERE id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $userHeader = $stmt->fetch();

    $nomeUsuarioHeader = $userHeader['nome_usuario'] ?? 'Usuário';
    $fotoPerfilPath = $userHeader['foto_perfil'] ?? '';
    echo "<!-- FOTO DEBUG: $fotoPerfilPath -->";

    // Caminho absoluto real do arquivo
    if (!empty($fotoPerfilPath)) {
      $absolutePath = $_SERVER['DOCUMENT_ROOT'] . '/' . ltrim($fotoPerfilPath, '/');
  
      if (file_exists($absolutePath)) {
          $fotoPerfilUrl = $basePath . $fotoPerfilPath;
      } else {
          // fallback: pode ser bug de cache ou arquivo deletado
          $fotoPerfilUrl = "https://ui-avatars.com/api/?name=" . urlencode($nomeUsuarioHeader) . "&background=ccc&color=333&rounded=true";
      }
  } else {
      $fotoPerfilUrl = "https://ui-avatars.com/api/?name=" . urlencode($nomeUsuarioHeader) . "&background=ccc&color=333&rounded=true";
  }
  
}
?>

<?php
echo '<!-- Avatar debug: ' . $fotoPerfilUrl . ' -->';
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sabores & Sabores</title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <!-- CSS -->
  <link rel="stylesheet" href="<?= $basePath ?>assets/css/topbar.css">
  <link rel="stylesheet" href="<?= $basePath ?>assets/css/search_desktop.css">
  <link rel="stylesheet" href="<?= $basePath ?>assets/css/desktop_navbar.css">
  <link rel="stylesheet" href="<?= $basePath ?>assets/css/sidebar_menu.css">
  <link rel="stylesheet" href="<?= $basePath ?>assets/css/responsive_mobile.css">
   <link rel="stylesheet" href="<?= $basePath ?>assets/css/navbar_responsive.css">
  <link rel="stylesheet" href="../../assets/css/usuario.css">
  <link rel="stylesheet" href="../../assets/css/editar_perfil.css">
  <link rel="stylesheet" href="../../assets/css/avatar.css">
  <?php if (isset($formPage) && $formPage === true): ?>
    <link rel="stylesheet" href="<?= $basePath ?>assets/css/form_style.css">
  <?php endif; ?>
 <link rel="stylesheet" href="<?= $basePath ?>assets/css/style.css">
</head>
<body>

<!-- Sidebar Menu (OFF-CANVAS) -->
<div class="sidebar-menu" id="sidebarMenu">
  <span class="close-btn" id="closeSidebar">&times;</span>
  <div class="sidebar-header">Categorias</div>
  <ul>
    <li><i class="fas fa-drumstick-bite"></i> <a href="<?= $basePath ?>pages/frango.php">Frango</a></li>
    <li><i class="fas fa-bacon"></i> <a href="<?= $basePath ?>pages/carne.php">Carne</a></li>
    <li><i class="fas fa-ice-cream"></i> <a href="<?= $basePath ?>pages/doces.php">Doces</a></li>
    <li><i class="fas fa-leaf"></i> <a href="<?= $basePath ?>pages/saladas.php">Saladas</a></li>
    <li><i class="fas fa-wine-glass"></i> <a href="<?= $basePath ?>pages/bebidas.php">Bebidas</a></li>
  </ul>
</div>

<!-- Alertas -->
<div id="dynamic-alert-container" style="position: fixed; top: 20px; right: 20px; z-index: 1050;"></div>

<!-- TOP BAR -->
<div class="top-bar">
  <!-- Logo -->
  <div class="top-left">
    <a href="<?= $basePath ?>index.php">
      <img src="<?= $basePath ?>assets/images/logo.png" alt="Sabores & Sabores">
    </a>
  </div>

  <!-- Busca desktop -->
  <div class="search-bar">
    <input type="text" placeholder="Procurar receita...">
    <button><i class="fas fa-search"></i></button>
  </div>

  <!-- Ícone de perfil -->
  <div class="profile-icon" id="profileButton">
  <?php
$isCustomAvatar = strpos($fotoPerfilUrl, 'ui-avatars.com') === false;
$imgSrc = $isCustomAvatar
    ? htmlspecialchars($fotoPerfilUrl) . '?t=' . time()
    : htmlspecialchars($fotoPerfilUrl);
?>
<img src="<?= $imgSrc ?>" alt="Foto do usuário" style="width: 36px; height: 36px; border-radius: 50%; object-fit: cover;">

  </div>
    <div class="profile-menu" id="profileMenu"></div>
  </div>

  <!-- Botões mobile: menu e lupa -->
  <button id="hamburgerButton" class="hamburger-icon" aria-label="Abrir menu">
    <i class="fas fa-bars"></i>
  </button>

  <button id="mobileSearchToggle" class="search-toggle-icon" aria-label="Buscar">
    <i class="fas fa-search"></i>
  </button>

  <!-- Barra de busca mobile -->
  <div id="mobileSearchBar" class="mobile-search-bar">
    <input type="text" placeholder="Procurar uma receita...">
    <button><i class="fas fa-search"></i></button>
  </div>
</div>

<?php
$currentFile = basename($_SERVER['PHP_SELF']);
$ocultarNavbar = in_array($currentFile, ['login.php', 'cadastro.php']);
?>

<?php if (!$ocultarNavbar): ?>
<!-- NAVBAR DESKTOP -->
<nav class="desktop-navbar">
  <ul class="nav-links">
    <li><a href="<?= $basePath ?>pages/frango.php">Frango</a></li>
    <li><a href="<?= $basePath ?>pages/carne.php">Carne</a></li>
    <li><a href="<?= $basePath ?>pages/doces.php">Doces</a></li>
    <li><a href="<?= $basePath ?>pages/saladas.php">Saladas</a></li>
    <li><a href="<?= $basePath ?>pages/bebidas.php">Bebidas</a></li>
  </ul>
</nav>
<?php endif; ?>
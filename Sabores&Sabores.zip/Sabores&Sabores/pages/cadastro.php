<?php
$formPage = true;
require_once('../includes/db.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../includes/header.php');

$mensagem = '';
$tipo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome_real = trim($_POST['nome_real'] ?? '');
    $username  = trim($_POST['nome_usuario'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $senha     = trim($_POST['senha'] ?? '');

    if (empty($nome_real) || empty($username) || empty($email) || empty($senha)) {
        $mensagem = "Preencha todos os campos.";
        $tipo = "erro";
    } else {
        // Verifica se já existe usuário ou email com PDO
        $check = $pdo->prepare("SELECT id FROM usuarios WHERE nome_usuario = :username OR email = :email");
        $check->execute([
            'username' => $username,
            'email' => $email
        ]);

        if ($check->fetch()) {
            $mensagem = "⚠️ Nome de usuário ou e-mail já em uso.";
            $tipo = "erro";
        } else {
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome_real, nome_usuario, email, senha_hash, data_cadastro) 
                                   VALUES (:nome_real, :nome_usuario, :email, :senha_hash, NOW())");

            if ($stmt->execute([
                'nome_real'   => $nome_real,
                'nome_usuario'=> $username,
                'email'       => $email,
                'senha_hash'  => $senha_hash
            ])) {
                header('Location: login.php?cadastro=sucesso');
                exit;
            } else {
                $mensagem = "Erro ao cadastrar. Tente novamente.";
                $tipo = "erro";
            }
        }
    }
}
?>

<div class="form-container">
    <h2>Criar conta</h2>
    <form method="POST">
        <div class="form-group">
            <label for="nome_real">Nome completo</label>
            <input type="text" class="form-control" name="nome_real" placeholder="Digite seu nome" required>
        </div>
        <div class="form-group">
            <label for="nome_usuario">Nome de usuário</label>
            <input type="text" class="form-control" name="nome_usuario" placeholder="Escolha um nome de usuário" required>
        </div>
        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" class="form-control" name="email" placeholder="Digite seu e-mail" required>
        </div>
        <div class="form-group">
            <label for="senha">Senha</label>
            <input type="password" class="form-control" name="senha" placeholder="Crie uma senha" required>
        </div>
        <button type="submit" class="btn btn-block botao-personalizado">Cadastrar</button>
        <p class="mt-3 text-center">Já tem uma conta? <a href="login.php">Entrar</a></p>
        <p class="mt-2 text-center"><a href="../index.php">← Voltar para a página inicial</a></p>
    </form>
</div>

<?php if (!empty($mensagem) && $tipo === 'erro'): ?>
<script>
    window.onload = function () {
        showAlert(<?= json_encode($mensagem) ?>, <?= json_encode($tipo) ?>);
    };
</script>
<?php endif; ?>

<?php include('../includes/footer.php'); ?>

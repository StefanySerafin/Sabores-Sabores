<?php include('../includes/header.php'); ?>

<div class="container mt-5">
    <h1 class="text-center mb-4">Receitas com Frango</h1>
    <p class="text-center">Explore deliciosas receitas com frango para todas as ocasiões.</p>

    <div class="row">
        <?php
        $receitas = [
            ["Frango Assado", "Uma receita tradicional com temperos caseiros.", "frango-assado.jpg"],
            ["Filé de Frango Grelhado", "Leve e saudável, ideal para o dia a dia.", "file-frango.jpg"],
            ["Frango à Parmegiana", "Com queijo derretido e molho de tomate.", "frango-parmegiana.jpg"],
            ["Frango Xadrez", "Receita oriental com legumes e molho shoyu.", "frango-xadrez.jpg"],
            ["Frango ao Curry", "Sabor exótico com especiarias indianas.", "curry-frango.jpg"],
            ["Frango com Requeijão", "Cremoso e fácil de fazer.", "frango-requeijao2.jpg"],
            ["Frango Empanado", "Crocante por fora, suculento por dentro.", "frango-empanado.jpg"],
            ["Estrogonofe de Frango", "Clássico brasileiro com creme de leite.", "estrogonoff-frango.webp"],
            ["Frango com Batata", "Assado junto com legumes e temperos.", "frango-batata.jpg"],
            ["Frango ao Molho Branco", "Ideal para massas ou arroz branco.", "frango-branco.jpg"],
            ["Frango Desfiado ao Alho", "Simples, perfeito para recheios.", "frango-desfiado.jpg"],
            ["Frango com Mostarda e Mel", "Sabor agridoce e marcante.", "frango-mostarda.jpg"],
            ["Frango Picante Mexicano", "Com molho de pimenta e especiarias.", "frango-picante4.jpg"],
            ["Frango com Legumes na Panela", "Colorido e saudável.", "frango-legumes.jpg"],
            ["Coxinha de Frango", "Clássico salgado brasileiro.", "coxinha-frango.jpg"],
            ["Frango Teriyaki", "Inspirado na culinária japonesa.", "frango-teriyaki.jpg"]
        ];

        foreach ($receitas as $receita) {
            echo '
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <img src="../assets/images/' . $receita[2] . '" class="card-img h-100" alt="' . $receita[0] . '" style="object-fit: cover;">
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">' . $receita[0] . '</h5>
                                <p class="card-text">' . $receita[1] . '</p>
                                <a href="#" class="btn btn-primary btn-sm">Ver Receita</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

<?php include('../includes/header.php'); ?>

<div class="container mt-5">
    <h1 class="text-center mb-4">Receitas com Carne</h1>
    <p class="text-center">Saboreie as melhores receitas com carne para todos os gostos e ocasiões.</p>

    <div class="row">
        <?php
        $receitas = [
            ["Carne Assada", "Tradicional e suculenta, perfeita para o almoço de domingo.", "carne-assada.jpg"],
            ["Bife à Milanesa", "Empanado e crocante, ideal com arroz e feijão.", "bife-milanesa.jpg"],
            ["Carne de Panela", "Cozida lentamente com batatas e cenoura.", "carne-panela.jpg"],
            ["Filé Mignon ao Molho Madeira", "Sofisticado e muito saboroso.", "file-mignon.jpg"],
            ["Estrogonofe de Carne", "Um clássico brasileiro com creme de leite.", "strogonoff-carne.jpg"],
            ["Hambúrguer Caseiro", "Suculento e feito com carne moída temperada.", "hamburguer-caseiro.jpg"],
            ["Picanha na Churrasqueira", "Favorita dos brasileiros, com sal grosso.", "picanha-churrasqueira.jpg"],
            ["Almôndegas ao Molho", "Perfeitas com macarrão ou arroz.", "molho-almondegas.jpg"],
            ["Escondidinho de Carne", "Recheado com purê de batata e carne moída.", "carne-escondidinho.jpg"],
            ["Rocambole de Carne", "Recheado com queijo e presunto.", "carne-rocambole.jpg"],
            ["Carne Moída com Legumes", "Prato rápido, saudável e versátil.", "moida-legumes.jpg"],
            ["Costela Assada", "Macia e desmanchando na boca.", "costela-assada.jpg"],
            ["Carne Louca", "Desfiada e temperada, ideal para sanduíches.", "carne-louca.jpg"],
            ["Kafta no Espeto", "Receita árabe com temperos marcantes.", "kafta-espeto.jpg"],
            ["Picadinho de Carne", "Simples e saboroso para o dia a dia.", "picadinho-carne.jpg"],
            ["Maminha ao Forno", "Com manteiga e ervas, super suculenta.", "maminha-forno.jpg"]
        ];

        foreach ($receitas as $receita) {
            echo '
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <img src="../assets/images/' . $receita[2] . '" class="card-img h-100" alt="' . $receita[0] . '" style="object-fit: cover;">
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">' . $receita[0] . '</h5>
                                <p class="card-text">' . $receita[1] . '</p>
                                <a href="#" class="btn btn-primary btn-sm">Ver Receita</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

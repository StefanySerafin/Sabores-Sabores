<?php
session_start();
require_once '../../includes/db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

$formPage = true;
include '../../includes/header.php';

$usuarioId = $_SESSION['usuario_id'];
$stmt = $pdo->prepare("SELECT *, nome_usuario FROM usuarios WHERE id = ?");
$stmt->execute([$usuarioId]);
$usuario = $stmt->fetch();

$nome = $usuario['nome_real'] ?? '';
$nomeUsuario = $usuario['nome_usuario'] ?? 'Usuário';
$bio = $usuario['mini_bio'] ?? '';
$email = $usuario['email'] ?? '';
$genero = $usuario['genero'] ?? '';
$cep = $usuario['cep'] ?? '';
$pais = $usuario['pais'] ?? '';
$dataNascimento = $usuario['data_nascimento'] ?? null;
$facebook = $usuario['facebook'] ?? '';
$twitter = $usuario['twitter'] ?? '';
$pinterest = $usuario['pinterest'] ?? '';
$instagram = $usuario['instagram'] ?? '';
$youtube = $usuario['youtube'] ?? '';

[$ano, $mes, $dia] = $dataNascimento ? explode('-', $dataNascimento) : [null, null, null];

$avatarPath = $usuario['foto_perfil'] ?? '';
$avatarUrl = (!empty($avatarPath) && file_exists('../../' . $avatarPath))
    ? '../../' . $avatarPath
    : 'https://ui-avatars.com/api/?name=' . urlencode($nomeUsuario) . '&background=ddd&color=444&rounded=true';
?>

<!-- Estilos -->
<link rel="stylesheet" href="../../assets/css/usuario.css">
<link rel="stylesheet" href="../../assets/css/avatar.css">

<div class="usuario-container">
  <!-- Navegação -->
  <nav class="usuario-nav">
    <ul>
      <li><a href="conta.php">Minha conta</a></li>
      <li><a href="favoritos.php">Receitas favoritas</a></li>
      <li><a href="avaliacoes.php">Minhas avaliações</a></li>
      <li><a href="comentarios.php">Comentários</a></li>
      <li><a href="fotos.php">Fotos</a></li>
      <li><a href="receitas.php">Receitas</a></li>
      <li class="active"><a href="editar.php">Editar Perfil</a></li>
    </ul>
  </nav>

  <!-- Avatar central -->
  <div class="usuario-header-center">
    <form method="POST" action="editar_salvar.php" enctype="multipart/form-data" id="formAvatar">
      <div class="avatar-edit-container">
        <img src="<?= htmlspecialchars($avatarUrl) ?>?t=<?= time() ?>" id="avatarPreview" class="avatar-hoverable">
        <div class="avatar-actions">
          <label for="avatarInput" class="btn-editar">📷 Alterar</label>
          <?php if (!empty($avatarPath)) : ?>
            <button type="submit" name="remover_avatar" class="btn-remover">🗑️ Remover</button>
          <?php endif; ?>
        </div>
        <input type="file" name="avatar" id="avatarInput" accept="image/*" style="display: none;">
      </div>
    </form>
  </div>

  <form method="POST" action="editar_salvar.php" class="form-editar-perfil">

<div class="form-group">
  <label>Gênero:</label>
  <div class="radio-group">
    <label><input type="radio" name="genero" value="M" <?= $genero == 'M' ? 'checked' : '' ?>> Masculino</label>
    <label><input type="radio" name="genero" value="F" <?= $genero == 'F' ? 'checked' : '' ?>> Feminino</label>
  </div>
</div>

<div class="form-group">
  <label for="apelido">Alterar Apelido*</label>
  <input type="text" id="apelido" name="nome_usuario" class="form-control" value="<?= htmlspecialchars($nomeUsuario) ?>">
</div>

<div class="form-group">
  <label for="nome">Nome</label>
  <input type="text" id="nome" name="nome" class="form-control" value="<?= htmlspecialchars($nome) ?>">
</div>

<div class="form-group">
  <label for="bio">Mini Biografia</label>
  <textarea id="bio" name="bio" class="form-control" rows="4"><?= htmlspecialchars($bio) ?></textarea>
</div>

<h3>Redes sociais</h3>

<div class="form-group"><input type="url" name="facebook" class="form-control" placeholder="Facebook" value="<?= htmlspecialchars($facebook) ?>"></div>
<div class="form-group"><input type="url" name="twitter" class="form-control" placeholder="Twitter" value="<?= htmlspecialchars($twitter) ?>"></div>
<div class="form-group"><input type="url" name="pinterest" class="form-control" placeholder="Pinterest" value="<?= htmlspecialchars($pinterest) ?>"></div>
<div class="form-group"><input type="url" name="instagram" class="form-control" placeholder="Instagram" value="<?= htmlspecialchars($instagram) ?>"></div>
<div class="form-group"><input type="url" name="youtube" class="form-control" placeholder="Youtube" value="<?= htmlspecialchars($youtube) ?>"></div>

<h3>Endereço e contato</h3>

<div class="form-group">
  <label for="email">E-mail</label>
  <input type="email" id="email" name="email" class="form-control" required value="<?= htmlspecialchars($email) ?>">
</div>

<div class="form-group">
  <label for="cep">CEP</label>
  <input type="text" id="cep" name="cep" class="form-control" value="<?= htmlspecialchars($cep) ?>">
</div>

<div class="form-group">
  <label for="pais">País</label>
  <select name="pais" id="pais" class="form-control">
    <option value="">Selecione o país</option>
    <!-- Preencha dinamicamente se quiser -->
  </select>
</div>

<h3>Data de nascimento</h3>

<div class="form-group campo-duplo">
  <select name="dia" class="form-control" style="max-width: 100px;">
    <option value="">Dia</option>
    <?php for ($i = 1; $i <= 31; $i++) echo "<option value='$i'" . ($dia == $i ? ' selected' : '') . ">$i</option>"; ?>
  </select>
  <select name="mes" id="mes" class="form-control" style="max-width: 140px;"></select>
  <select name="ano" id="ano" class="form-control" style="max-width: 120px;"></select>
</div>

<h3>Nova senha</h3>

<div class="form-group">
  <input type="password" name="nova_senha" class="form-control" placeholder="Nova senha">
</div>
<div class="form-group">
  <input type="password" name="confirmar_senha" class="form-control" placeholder="Confirmar nova senha">
</div>

<div class="form-group">
  <button type="submit" class="btn btn-salvar">Salvar tudo</button>
</div>
</form>



<?php include '../../includes/footer.php'; ?>


<?php
session_start();
require_once '../../includes/db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

// 🔹 Remover avatar
if (isset($_POST['remover_avatar'])) {
    // Buscar caminho atual da imagem
    $stmt = $pdo->prepare("SELECT foto_perfil FROM usuarios WHERE id = ?");
    $stmt->execute([$usuarioId]);
    $usuario = $stmt->fetch();
    $caminhoAtual = $usuario['foto_perfil'] ?? '';

    // Apagar o arquivo físico se existir
    if (!empty($caminhoAtual) && file_exists('../../' . $caminhoAtual)) {
        unlink('../../' . $caminhoAtual);
    }

    // Limpar o campo no banco
    $stmt = $pdo->prepare("UPDATE usuarios SET foto_perfil = NULL WHERE id = ?");
    $stmt->execute([$usuarioId]);

    header("Location: editar.php?avatar=removido");
    exit;
}


// 🔹 Upload de imagem de perfil
if (!empty($_FILES['avatar']['tmp_name'])) {
    $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
    $permitidos = ['jpg', 'jpeg', 'png', 'webp'];

    if (in_array($ext, $permitidos) && $_FILES['avatar']['size'] <= 10485760) {
        $nome = 'avatar_' . $usuarioId . '.' . $ext;
        $destino = '../../assets/uploads/' . $nome;

        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $destino)) {
            $relativo = 'assets/uploads/' . $nome;
            $stmt = $pdo->prepare("UPDATE usuarios SET foto_perfil = ? WHERE id = ?");
            $stmt->execute([$relativo, $usuarioId]);
        }
    }
    header("Location: editar.php?avatar=ok");
    exit;
}

if (move_uploaded_file($_FILES['avatar']['tmp_name'], $destino)) {
    $relativo = 'assets/uploads/' . $nome;
    
    // 🔸 Atualiza o campo no banco, mesmo se for o mesmo valor
    $stmt = $pdo->prepare("UPDATE usuarios SET foto_perfil = ? WHERE id = ?");
    $stmt->execute([$relativo, $usuarioId]);
}


// 🔹 Atualização de todos os dados
$nome_real  = trim($_POST['nome'] ?? '');
$nomeUsuario  = trim($_POST['nome_usuario'] ?? '');
$genero     = $_POST['genero'] ?? '';
$bio        = trim($_POST['bio'] ?? '');
$email      = trim($_POST['email'] ?? '');
$cep        = trim($_POST['cep'] ?? '');
$pais       = $_POST['pais'] ?? '';
$dia        = str_pad($_POST['dia'] ?? '', 2, '0', STR_PAD_LEFT);
$mes        = str_pad($_POST['mes'] ?? '', 2, '0', STR_PAD_LEFT);
$ano        = $_POST['ano'] ?? '';
$data_nasc  = ($dia && $mes && $ano) ? "$ano-$mes-$dia" : null;
$facebook   = trim($_POST['facebook'] ?? '');
$twitter    = trim($_POST['twitter'] ?? '');
$pinterest  = trim($_POST['pinterest'] ?? '');
$instagram  = trim($_POST['instagram'] ?? '');
$youtube    = trim($_POST['youtube'] ?? '');

// Atualizar tudo
$stmt = $pdo->prepare("UPDATE usuarios SET 
  nome_real = ?, nome_usuario = ?, genero = ?, mini_bio = ?, email = ?, cep = ?, pais = ?, data_nascimento = ?, 
  facebook = ?, twitter = ?, pinterest = ?, instagram = ?, youtube = ?
  WHERE id = ?");

$stmt->execute([
  $nome_real, $nomeUsuario, $genero, $bio, $email, $cep, $pais, $data_nasc,
  $facebook, $twitter, $pinterest, $instagram, $youtube, $usuarioId
]);



// 🔹 Atualizar senha (opcional)
if (!empty($_POST['nova_senha']) && $_POST['nova_senha'] === $_POST['confirmar_senha']) {
    $senha = $_POST['nova_senha'];
    if (strlen($senha) >= 8) {
        $hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE usuarios SET senha_hash = ? WHERE id = ?");
        $stmt->execute([$hash, $usuarioId]);
    }
}

if (isset($_POST['excluir_conta'])) {
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->execute([$usuarioId]);

    session_destroy();
    header("Location: ../login.php?conta=excluida");
    exit;
}


header("Location: editar.php?salvo=ok");
exit;

<?php
session_start();
require_once '../../includes/db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

$formPage = true;
include '../../includes/header.php';

$usuarioId = $_SESSION['usuario_id'];
$stmt = $pdo->prepare("SELECT nome_usuario, nome_real, email, foto_perfil FROM usuarios WHERE id = ?");
$stmt->execute([$usuarioId]);
$usuario = $stmt->fetch();

$nomeUsuario = $usuario['nome_usuario'] ?? 'Usuário';
$nomeReal = $usuario['nome_real'] ?? '';
$email = $usuario['email'] ?? '';
$fotoPerfil = $usuario['foto_perfil'] ?? '';

$avatarUrl = (!empty($fotoPerfil) && file_exists('../../' . $fotoPerfil))
    ? '../../' . $fotoPerfil
    : 'https://ui-avatars.com/api/?name=' . urlencode($nomeUsuario) . '&background=ccc&color=333&rounded=true&size=128';
?>

<link rel="stylesheet" href="../../assets/css/usuario.css">

<div class="usuario-container">
  <div class="usuario-header">
    <div class="usuario-avatar">
      <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="Avatar do usuário">
    </div>
    <div class="usuario-info">
      <h2><?= htmlspecialchars($nomeUsuario) ?></h2>
      <?php if (!empty($nomeReal)): ?>
        <p style="font-size: 0.85rem; color: #777; margin-top: 4px;">Nome: <?= htmlspecialchars($nomeReal) ?></p>
      <?php endif; ?>
      <span class="tag-membro">Membro</span>
      <p class="progresso-perfil">24% do perfil concluído</p>
    </div>
  </div>

<?php
$paginaAtual = basename($_SERVER['PHP_SELF']);
$menu = [
    'conta.php' => 'Minha conta',
    'favoritos.php' => 'Receitas favoritas',
    'avaliacoes.php' => 'Minhas avaliações',
    'comentarios.php' => 'Comentários',
    'fotos.php' => 'Fotos',
    'receitas.php' => 'Receitas',
    'editar.php' => 'Editar Perfil'
];
?>

<nav class="usuario-nav">
  <ul>
    <?php foreach ($menu as $arquivo => $titulo): ?>
      <li class="<?= ($paginaAtual === $arquivo) ? 'active' : '' ?>">
        <a href="<?= $arquivo ?>"><?= $titulo ?></a>
      </li>
    <?php endforeach; ?>
  </ul>
</nav>

  <div class="usuario-conteudo">
    <h3>Minhas Fotos</h3>
    <p>Você ainda não enviou fotos de receita.</p>
    <p>Para enviar uma foto, entre na receita desejada e clique em <strong>“Enviar sua foto”</strong>.</p>
  </div>
</div>

<?php include '../../includes/footer.php'; ?>

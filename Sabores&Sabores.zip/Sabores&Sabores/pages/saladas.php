<?php include('../includes/header.php'); ?>

<div class="container mt-5">
    <h1 class="text-center mb-4">Receitas de Saladas</h1>
    <p class="text-center">Refrescantes, leves e perfeitas para qualquer ocasião!</p>

    <div class="row">
        <?php
        $receitas = [
            ["Salada Caesar", "Clássica com alface, frango grelhado, croutons e molho especial.", "salada-caesar.jpg"],
            ["Salada Grega", "Com tomate, pepino, azeitona, cebola roxa e queijo feta.", "salada-grega.jpg"],
            ["Salada de Grão-de-Bico", "Rica em fibras e proteínas, com legumes frescos.", "salada-grao.jpg"],
            ["Salada de Frutas", "Colorida, nutritiva e perfeita como sobremesa ou lanche.", "salada-frutas.jpg"],
            ["Salada de Batata", "Tradicional, com maionese e ervas.", "salada-batata.jpg"],
            ["Salada Tropical", "Com manga, frango e molho agridoce.", "salada-tropical.jpg"],
            ["Salada Caprese", "Tomate, mussarela de búfala e manjericão fresco.", "salada-caprese.jpg"],
            ["Salada de Macarrão", "Colorida e prática, com vegetais e atum.", "salada-macarrao.jpg"],
            ["Salada de Quinoa", "Proteica, saudável e cheia de sabor.", "salada-quinoa.jpg"],
            ["Salada Waldorf", "Maçã, aipo e nozes com molho leve.", "salada-waldorf.jpg"],
            ["Salada de Couve", "Crocante, com limão, alho e parmesão.", "salada-couve.jpg"],
            ["Salada de Alface com Abacate", "Refrescante e rica em gorduras boas.", "salada-abacate.jpg"],
            ["Salada de Lentilha", "Nutritiva e ótima para refeições leves.", "salada-lentilha.jpg"],
            ["Salada de Pepino com Iogurte", "Refrescante e leve, estilo grego.", "salada-pepino.jpg"],
            ["Salada Colorida com Cenoura", "Rica em fibras e antioxidantes.", "salada-cenoura.jpg"],
            ["Salada de Ovo com Maionese", "Rápida e saborosa para acompanhar pratos.", "salada-ovo.jpg"]
        ];

        foreach ($receitas as $receita) {
            echo '
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <img src="../assets/images/' . $receita[2] . '" class="card-img h-100" alt="' . $receita[0] . '" style="object-fit: cover;">
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">' . $receita[0] . '</h5>
                                <p class="card-text">' . $receita[1] . '</p>
                                <a href="#" class="btn btn-primary btn-sm">Ver Receita</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

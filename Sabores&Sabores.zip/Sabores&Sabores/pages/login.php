<?php
$formPage = true;
require_once('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$mensagem = '';
$tipo = '';

// Processo de login - antes de qualquer HTML!
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if (empty($login) || empty($senha)) {
        $mensagem = "Preencha todos os campos.";
        $tipo = 'erro';
    } else {
        $stmt = $pdo->prepare("SELECT id, nome_usuario, senha_hash FROM usuarios WHERE email = :login OR nome_usuario = :login");
        $stmt->execute(['login' => $login]);
        $usuario = $stmt->fetch();

        if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome_usuario'];

            // Redireciona para a conta
            header('Location: ../pages/usuario/conta.php');
            exit;
        } else {
            $mensagem = "❌ Usuário ou senha incorretos.";
            $tipo = 'erro';
        }
    }
}

include('../includes/header.php');
?>

<!-- FORMULÁRIO DE LOGIN -->
<div class="form-container">
    <h2>Entrar</h2>
    <form method="POST">
        <div class="form-group">
            <label for="login">E-mail ou nome de usuário</label>
            <input type="text" class="form-control" name="login" placeholder="Digite seu e-mail ou nome de usuário" required>
        </div>
        <div class="form-group">
            <label for="senha">Senha</label>
            <input type="password" class="form-control" name="senha" placeholder="Digite sua senha" required>
        </div>
        <button type="submit" class="btn btn-block botao-personalizado">Entrar</button>
        <p class="mt-3 text-center">Não tem uma conta? <a href="cadastro.php">Cadastrar</a></p>
        <p class="mt-2 text-center"><a href="../index.php">← Voltar para a página inicial</a></p>
    </form>
</div>

<?php if (!empty($mensagem)): ?>
<script>
    window.onload = function () {
        showAlert(<?= json_encode($mensagem) ?>, <?= json_encode($tipo) ?>);
    };
</script>
<?php endif; ?>

<?php include('../includes/footer.php'); ?>

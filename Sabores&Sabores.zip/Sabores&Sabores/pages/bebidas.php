<?php include('../includes/header.php'); ?>

<div class="container mt-5">
    <h1 class="text-center mb-4">Receitas de Bebidas</h1>
    <p class="text-center">Bebidas deliciosas para refrescar, aquecer e impressionar!</p>

    <div class="row">
        <?php
        $bebidas = [
            ["Suco Detox", "Feito com couve, limão, maçã e gengibre.", "suco-detox.jpg"],
            ["Limonada Suíça", "Refrescante, com limão e leite condensado.", "limonada-suica.jpg"],
            ["Smoothie de Morango", "Batida cremosa com frutas e iogurte.", "smoothie-morango.jpg"],
            ["Café Gelado", "Perfeito para dias quentes.", "cafe-gelado.jpg"],
            ["Chocolate Quente Cremoso", "Para se aquecer nos dias frios.", "chocolate-quente.jpg"],
            ["Chá de Hibisco com Canela", "Aromático e funcional.", "cha-hibisci.jpg"],
            ["Suco de Maracujá", "Natural e calmante.", "suco-maracuja.jpg"],
            ["Milkshake de Chocolate", "Cremoso, doce e irresistível.", "milkshake-chocolate.jpg"],
            ["Capuccino Caseiro", "Com toque de canela e chocolate.", "capuccino-caseiro.jpg"],
            ["Água Saborizada com Frutas", "Saudável e refrescante.", "agua-frutada.jpg"],
            ["Suco de Melancia com Hortelã", "Refrescância pura!", "suco-melancia.jpg"],
            ["Vitamina de Banana", "Simples, nutritiva e rápida.", "vitamina-banana.jpg"],
            ["Suco Verde Energizante", "Com espinafre, pepino e limão.", "suco-verde.jpg"],
            ["Chá Gelado de Pêssego", "Leve, doce e ideal para o verão.", "cha-pessego.jpg"],
            ["Smoothie de Manga", "Doce e tropical.", "smoothie-manga.jpg"],
            ["Suco de Acerola", "Rico em vitamina C, ótimo para imunidade.", "suco-acerola.jpg"]
        ];

        foreach ($bebidas as $bebida) {
            echo '
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <img src="../assets/images/' . $bebida[2] . '" class="card-img h-100" alt="' . $bebida[0] . '" style="object-fit: cover;">
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">' . $bebida[0] . '</h5>
                                <p class="card-text">' . $bebida[1] . '</p>
                                <a href="#" class="btn btn-primary btn-sm">Ver Receita</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

<?php include('../includes/header.php'); ?>

<div class="container mt-5">
    <h1 class="text-center mb-4">Receitas de Doces</h1>
    <p class="text-center">Descubra sobremesas irresistíveis para adoçar seus dias!</p>

    <div class="row">
        <?php
        $receitas = [
            ["Brigadeiro", "Clássico brasileiro feito com leite condensado e chocolate.", "brigadeiro.jpg"],
            ["Pudim de Leite", "Sobremesa tradicional com calda de caramelo.", "pudim.jpg"],
            ["Bolo de Cenoura", "Fofo e coberto com calda de chocolate.", "bolo-cenoura.jpg"],
            ["Mousse de Maracujá", "Cremosa e com toque cítrico.", "mousse-maracuja.jpg"],
            ["Torta de Limão", "Doce e azedinha com cobertura de merengue.", "torta-limao.jpg"],
            ["Beijinho", "Doce de coco enrolado e coberto com açúcar.", "beijinho.jpg"],
            ["Bolo de Chocolate", "Molhadinho e intenso no sabor.", "bolo-chocolate.jpg"],
            ["Pavê de Bolacha", "Camadas de creme e biscoito, uma delícia gelada.", "pave.jpg"],
            ["Quindim", "Doce de gema com coco e brilho dourado.", "quindim.jpg"],
            ["Arroz Doce", "Doce caseiro com canela e leite.", "arroz-doce.jpg"],
            ["Doce de Abóbora", "Caseiro, com cravo e canela.", "doce-abobora.jpg"],
            ["Rocambole de Goiabada", "Bolo enrolado com recheio doce.", "rocambole.jpg"],
            ["Manjar Branco", "Tradicional com calda de ameixa.", "manjar.jpg"],
            ["Banana Caramelizada", "Simples e deliciosa, perfeita com sorvete.", "banana-caramelizada.jpg"],
            ["Torta de Maçã", "Clássica torta americana com maçãs cozidas.", "torta-maca.jpg"],
            ["Churros", "Frito e recheado com doce de leite ou chocolate.", "churros.jpg"]
        ];

        foreach ($receitas as $receita) {
            echo '
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <img src="../assets/images/' . $receita[2] . '" class="card-img h-100" alt="' . $receita[0] . '" style="object-fit: cover;">
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">' . $receita[0] . '</h5>
                                <p class="card-text">' . $receita[1] . '</p>
                                <a href="#" class="btn btn-primary btn-sm">Ver Receita</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

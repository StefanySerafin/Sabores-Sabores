<?php include('includes/header.php'); ?>

<!-- Carrossel de imagens -->
<div id="carouselExampleSlidesOnly" class="carousel slide carousel-fade" data-ride="carousel" data-interval="3000">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="d-block w-100" src="https://i.postimg.cc/DfdWxytH/carrossel-NHOQUE.jpg" alt="Chocolate Derretido">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://i.postimg.cc/rFrPB3NB/bolo-CENOURA.jpg" alt="Slide 2">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://i.postimg.cc/8C03QSxV/SALADA.jpg" alt="Slide 3">
        </div>
    </div>

    <a class="carousel-control-prev" href="#carouselExampleSlidesOnly" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Anterior</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleSlidesOnly" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Próximo</span>
    </a>
</div>

<div style="padding:20px; font-family: 'Georgia', serif;">
    <h1>Bem-vindo à Sabores&Sabores</h1>
    <p>Aqui você pode encontrar diversas receitas de seu gosto.</p>
    <p>Venha saborear nossas deliciosas guloseimas!!.</p>
</div>

<?php include('includes/footer.php'); ?>
